"""
Script para insertar datos de ejemplo en la base de datos biblioteca.db
Compatible con Windows, Mac y Linux
Capacitaciones: Bases de datos, Escritura Académica, Estilo APA, 
                Gestor Bibliográfico, Inducciones, Visibilidad científica, Visita de grupos
"""

import sqlite3
from datetime import datetime

def insertar_datos_ejemplo():
    try:
        # Conectar a la base de datos
        conn = sqlite3.connect('biblioteca.db')
        cursor = conn.cursor()
        
        print("📊 Insertando datos de ejemplo en biblioteca.db...")
        print("-" * 60)
        
        # Datos de ejemplo para el año 2022
        datos_2022 = [
            ('Bases de datos', 'Biblioteca UCLA', 'María López', 'Bibliotecología', '1001', 'Juan Pérez', 'Psicología (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2022-03-15'),
            ('Bases de datos', 'Biblioteca UCLA', 'María López', 'Bibliotecología', '1002', 'Ana García', 'Derecho (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2022-03-15'),
            ('Bases de datos', 'Biblioteca UCLA', 'María López', 'Bibliotecología', '1003', 'Carlos Ruiz', 'Ingeniería de Sistemas (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2022-03-15'),
            ('Bases de datos', 'Biblioteca UCLA', 'María López', 'Bibliotecología', '1004', 'Sofía Ramírez', 'Comunicación Social (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2022-03-15'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '1005', 'Laura Torres', 'Psicología (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2022-04-20'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '1006', 'Diego Martínez', 'Comunicación Social (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2022-04-20'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '1007', 'Miguel Ángel', 'Administración de Empresas (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2022-04-20'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '1008', 'Valentina Cruz', 'Derecho (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2022-04-20'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '1009', 'Andrés Vargas', 'Arquitectura (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2022-04-20'),
            ('Gestor Bibliográfico', 'Biblioteca UCLA', 'Carmen Silva', 'Investigación', '1010', 'Camila Moreno', 'Psicología (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2022-05-10'),
            ('Gestor Bibliográfico', 'Biblioteca UCLA', 'Carmen Silva', 'Investigación', '1011', 'Roberto Díaz', 'Ingeniería Civil (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2022-05-10'),
            ('Gestor Bibliográfico', 'Biblioteca UCLA', 'Carmen Silva', 'Investigación', '1012', 'Daniela Ortiz', 'Economía (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2022-05-10'),
            ('Escritura Académica', 'Biblioteca UCLA', 'Luis Pacheco', 'Redacción', '1013', 'Felipe Castro', 'Comunicación Social (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2022-06-15'),
            ('Escritura Académica', 'Biblioteca UCLA', 'Luis Pacheco', 'Redacción', '1014', 'Isabella Rojas', 'Derecho (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2022-06-15'),
            ('Inducciones', 'Biblioteca UCLA', 'Ana Beltrán', 'Bibliotecología', '1015', 'Mateo Jiménez', 'Psicología (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2022-02-10'),
            ('Inducciones', 'Biblioteca UCLA', 'Ana Beltrán', 'Bibliotecología', '1016', 'Lucía Mendoza', 'Administración de Empresas (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2022-02-10'),
            ('Inducciones', 'Biblioteca UCLA', 'Ana Beltrán', 'Bibliotecología', '1017', 'Santiago Herrera', 'Ingeniería de Sistemas (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2022-02-10'),
            ('Visita de grupos', 'Biblioteca UCLA', 'Gloria Martínez', 'Bibliotecología', '1018', 'Mariana Parra', 'Derecho (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2022-09-20'),
            ('Visita de grupos', 'Biblioteca UCLA', 'Gloria Martínez', 'Bibliotecología', '1019', 'Sebastián Ríos', 'Arquitectura (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2022-09-20'),
        ]
        
        # Datos de ejemplo para el año 2023
        datos_2023 = [
            ('Bases de datos', 'Biblioteca UCLA', 'María López', 'Bibliotecología', '2001', 'Valeria Sánchez', 'Psicología (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-03-18'),
            ('Bases de datos', 'Biblioteca UCLA', 'María López', 'Bibliotecología', '2002', 'Nicolás Franco', 'Derecho (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-03-18'),
            ('Bases de datos', 'Biblioteca UCLA', 'María López', 'Bibliotecología', '2003', 'Gabriela Luna', 'Arquitectura (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-03-18'),
            ('Bases de datos', 'Biblioteca UCLA', 'María López', 'Bibliotecología', '2004', 'Emilio Navarro', 'Ingeniería de Sistemas (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-03-18'),
            ('Bases de datos', 'Biblioteca UCLA', 'María López', 'Bibliotecología', '2005', 'Paulina Vega', 'Economía (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-03-18'),
            ('Bases de datos', 'Biblioteca UCLA', 'María López', 'Bibliotecología', '2006', 'Alejandro Gil', 'Comunicación Social (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-03-18'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '2007', 'Renata Molina', 'Psicología (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2023-04-22'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '2008', 'Tomás Aguilar', 'Comunicación Social (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2023-04-22'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '2009', 'Juliana Reyes', 'Administración de Empresas (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2023-04-22'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '2010', 'Martín Flores', 'Derecho (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2023-04-22'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '2011', 'Elena Campos', 'Ingeniería Industrial (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2023-04-22'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '2012', 'Ricardo Ospina', 'Psicología (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2023-04-22'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '2013', 'Carolina Pineda', 'Arquitectura (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2023-04-22'),
            ('Gestor Bibliográfico', 'Biblioteca UCLA', 'Carmen Silva', 'Investigación', '2014', 'Javier Suárez', 'Ingeniería Civil (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-05-12'),
            ('Gestor Bibliográfico', 'Biblioteca UCLA', 'Carmen Silva', 'Investigación', '2015', 'Natalia Romero', 'Psicología (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-05-12'),
            ('Gestor Bibliográfico', 'Biblioteca UCLA', 'Carmen Silva', 'Investigación', '2016', 'Oscar Medina', 'Comunicación Social (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-05-12'),
            ('Gestor Bibliográfico', 'Biblioteca UCLA', 'Carmen Silva', 'Investigación', '2017', 'Patricia Álvarez', 'Ingeniería de Sistemas (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-05-12'),
            ('Gestor Bibliográfico', 'Biblioteca UCLA', 'Carmen Silva', 'Investigación', '2018', 'Rodrigo Bermúdez', 'Derecho (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-05-12'),
            ('Escritura Académica', 'Biblioteca UCLA', 'Luis Pacheco', 'Redacción', '2019', 'Adriana Cárdenas', 'Administración de Empresas (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2023-06-18'),
            ('Escritura Académica', 'Biblioteca UCLA', 'Luis Pacheco', 'Redacción', '2020', 'Esteban Cortés', 'Psicología (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2023-06-18'),
            ('Escritura Académica', 'Biblioteca UCLA', 'Luis Pacheco', 'Redacción', '2021', 'Fernanda Duarte', 'Comunicación Social (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2023-06-18'),
            ('Escritura Académica', 'Biblioteca UCLA', 'Luis Pacheco', 'Redacción', '2022', 'Guillermo Estrada', 'Arquitectura (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2023-06-18'),
            ('Inducciones', 'Biblioteca UCLA', 'Ana Beltrán', 'Bibliotecología', '2023', 'Helena Fuentes', 'Economía (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-02-08'),
            ('Inducciones', 'Biblioteca UCLA', 'Ana Beltrán', 'Bibliotecología', '2024', 'Iván Gallego', 'Psicología (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-02-08'),
            ('Inducciones', 'Biblioteca UCLA', 'Ana Beltrán', 'Bibliotecología', '2025', 'Jazmín Henao', 'Derecho (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-02-08'),
            ('Inducciones', 'Biblioteca UCLA', 'Ana Beltrán', 'Bibliotecología', '2026', 'Kevin Ibarra', 'Ingeniería Industrial (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-02-08'),
            ('Visibilidad científica', 'Biblioteca UCLA', 'Raúl Pérez', 'Investigación', '2027', 'Lorena Jaramillo', 'Psicología (Presencial)', 'Presencial', 'Docente', 'Sede Principal', '2023-07-15'),
            ('Visibilidad científica', 'Biblioteca UCLA', 'Raúl Pérez', 'Investigación', '2028', 'Manuel Lara', 'Derecho (Presencial)', 'Presencial', 'Docente', 'Sede Principal', '2023-07-15'),
            ('Visibilidad científica', 'Biblioteca UCLA', 'Raúl Pérez', 'Investigación', '2029', 'Nora Mejía', 'Ingeniería Industrial (Presencial)', 'Presencial', 'Docente', 'Sede Principal', '2023-07-15'),
            ('Visita de grupos', 'Biblioteca UCLA', 'Gloria Martínez', 'Bibliotecología', '2030', 'Pablo Nieto', 'Comunicación Social (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-09-25'),
            ('Visita de grupos', 'Biblioteca UCLA', 'Gloria Martínez', 'Bibliotecología', '2031', 'Rosa Quintero', 'Administración de Empresas (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-09-25'),
            ('Visita de grupos', 'Biblioteca UCLA', 'Gloria Martínez', 'Bibliotecología', '2032', 'Silvia Pérez', 'Arquitectura (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2023-09-25'),
        ]
        
        # Datos de ejemplo para el año 2024
        datos_2024 = [
            ('Bases de datos', 'Biblioteca UCLA', 'María López', 'Bibliotecología', '3001', 'Tatiana Quintero', 'Psicología (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-03-20'),
            ('Bases de datos', 'Biblioteca UCLA', 'María López', 'Bibliotecología', '3002', 'Ulises Ramos', 'Derecho (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-03-20'),
            ('Bases de datos', 'Biblioteca UCLA', 'María López', 'Bibliotecología', '3003', 'Victoria Salazar', 'Arquitectura (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-03-20'),
            ('Bases de datos', 'Biblioteca UCLA', 'María López', 'Bibliotecología', '3004', 'Walter Torres', 'Ingeniería de Sistemas (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-03-20'),
            ('Bases de datos', 'Biblioteca UCLA', 'María López', 'Bibliotecología', '3005', 'Ximena Uribe', 'Economía (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-03-20'),
            ('Bases de datos', 'Biblioteca UCLA', 'María López', 'Bibliotecología', '3006', 'Yolanda Valencia', 'Comunicación Social (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-03-20'),
            ('Bases de datos', 'Biblioteca UCLA', 'María López', 'Bibliotecología', '3007', 'Zaira Vargas', 'Psicología (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-03-20'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '3008', 'Alberto Arias', 'Psicología (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2024-04-18'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '3009', 'Beatriz Blanco', 'Comunicación Social (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2024-04-18'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '3010', 'César Cano', 'Administración de Empresas (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2024-04-18'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '3011', 'Diana Delgado', 'Derecho (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2024-04-18'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '3012', 'Eduardo Espinosa', 'Ingeniería Industrial (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2024-04-18'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '3013', 'Fabiana Figueroa', 'Psicología (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2024-04-18'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '3014', 'Gabriel Guerra', 'Arquitectura (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2024-04-18'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '3015', 'Hilda Herrera', 'Ingeniería Civil (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2024-04-18'),
            ('Estilo APA', 'Biblioteca UCLA', 'Pedro Gómez', 'Metodología', '3016', 'Ignacio Iglesias', 'Economía (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2024-04-18'),
            ('Gestor Bibliográfico', 'Biblioteca UCLA', 'Carmen Silva', 'Investigación', '3017', 'Jessica Juárez', 'Psicología (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-05-16'),
            ('Gestor Bibliográfico', 'Biblioteca UCLA', 'Carmen Silva', 'Investigación', '3018', 'Klaus López', 'Comunicación Social (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-05-16'),
            ('Gestor Bibliográfico', 'Biblioteca UCLA', 'Carmen Silva', 'Investigación', '3019', 'Lidia Montes', 'Ingeniería de Sistemas (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-05-16'),
            ('Gestor Bibliográfico', 'Biblioteca UCLA', 'Carmen Silva', 'Investigación', '3020', 'Mario Núñez', 'Derecho (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-05-16'),
            ('Gestor Bibliográfico', 'Biblioteca UCLA', 'Carmen Silva', 'Investigación', '3021', 'Nadia Ortega', 'Administración de Empresas (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-05-16'),
            ('Gestor Bibliográfico', 'Biblioteca UCLA', 'Carmen Silva', 'Investigación', '3022', 'Omar Paredes', 'Arquitectura (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-05-16'),
            ('Escritura Académica', 'Biblioteca UCLA', 'Luis Pacheco', 'Redacción', '3023', 'Pilar Quiroz', 'Psicología (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2024-06-12'),
            ('Escritura Académica', 'Biblioteca UCLA', 'Luis Pacheco', 'Redacción', '3024', 'Quique Rivas', 'Comunicación Social (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2024-06-12'),
            ('Escritura Académica', 'Biblioteca UCLA', 'Luis Pacheco', 'Redacción', '3025', 'Rocío Soto', 'Arquitectura (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2024-06-12'),
            ('Escritura Académica', 'Biblioteca UCLA', 'Luis Pacheco', 'Redacción', '3026', 'Samuel Torres', 'Economía (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2024-06-12'),
            ('Escritura Académica', 'Biblioteca UCLA', 'Luis Pacheco', 'Redacción', '3027', 'Teresa Uribe', 'Derecho (Presencial)', 'Virtual', 'Estudiante', 'Sede Principal', '2024-06-12'),
            ('Inducciones', 'Biblioteca UCLA', 'Ana Beltrán', 'Bibliotecología', '3028', 'Uriel Vásquez', 'Ingeniería de Sistemas (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-02-05'),
            ('Inducciones', 'Biblioteca UCLA', 'Ana Beltrán', 'Bibliotecología', '3029', 'Violeta Wagner', 'Psicología (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-02-05'),
            ('Inducciones', 'Biblioteca UCLA', 'Ana Beltrán', 'Bibliotecología', '3030', 'Waldo Ximénez', 'Derecho (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-02-05'),
            ('Inducciones', 'Biblioteca UCLA', 'Ana Beltrán', 'Bibliotecología', '3031', 'Yadira Yáñez', 'Administración de Empresas (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-02-05'),
            ('Inducciones', 'Biblioteca UCLA', 'Ana Beltrán', 'Bibliotecología', '3032', 'Zacarias Zambrano', 'Comunicación Social (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-02-05'),
            ('Visibilidad científica', 'Biblioteca UCLA', 'Raúl Pérez', 'Investigación', '3033', 'Amanda Acosta', 'Psicología (Presencial)', 'Presencial', 'Docente', 'Sede Principal', '2024-07-20'),
            ('Visibilidad científica', 'Biblioteca UCLA', 'Raúl Pérez', 'Investigación', '3034', 'Bruno Benítez', 'Derecho (Presencial)', 'Presencial', 'Docente', 'Sede Principal', '2024-07-20'),
            ('Visibilidad científica', 'Biblioteca UCLA', 'Raúl Pérez', 'Investigación', '3035', 'Carla Castro', 'Ingeniería Industrial (Presencial)', 'Presencial', 'Docente', 'Sede Principal', '2024-07-20'),
            ('Visibilidad científica', 'Biblioteca UCLA', 'Raúl Pérez', 'Investigación', '3036', 'Daniel Duarte', 'Economía (Presencial)', 'Presencial', 'Docente', 'Sede Principal', '2024-07-20'),
            ('Visita de grupos', 'Biblioteca UCLA', 'Gloria Martínez', 'Bibliotecología', '3037', 'Emma Escobar', 'Comunicación Social (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-09-18'),
            ('Visita de grupos', 'Biblioteca UCLA', 'Gloria Martínez', 'Bibliotecología', '3038', 'Franco Flores', 'Administración de Empresas (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-09-18'),
            ('Visita de grupos', 'Biblioteca UCLA', 'Gloria Martínez', 'Bibliotecología', '3039', 'Greta González', 'Arquitectura (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-09-18'),
            ('Visita de grupos', 'Biblioteca UCLA', 'Gloria Martínez', 'Bibliotecología', '3040', 'Hugo Hernández', 'Psicología (Presencial)', 'Presencial', 'Estudiante', 'Sede Principal', '2024-09-18'),
        ]
        
        # Combinar todos los datos
        todos_los_datos = datos_2022 + datos_2023 + datos_2024
        
        # Insertar datos
        contador = 0
        omitidos = 0
        for dato in todos_los_datos:
            try:
                cursor.execute("""
                    INSERT INTO asistencias 
                    (nombre_evento, dictado_por, docente, programa_docente, numero_identificacion, 
                     nombre_completo, programa_estudiante, modalidad, tipo_asistente, sede, fecha_evento)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, dato)
                contador += 1
            except sqlite3.IntegrityError:
                # Si el registro ya existe, lo saltamos
                omitidos += 1
                continue
        
        conn.commit()
        
        print("-" * 60)
        print(f"✅ Se insertaron {contador} registros correctamente")
        if omitidos > 0:
            print(f"⚠️  Se omitieron {omitidos} registros duplicados")
        print()
        
        # Verificar los datos insertados
        cursor.execute("SELECT COUNT(*) FROM asistencias")
        total = cursor.fetchone()[0]
        print(f"📊 Total de registros en la base de datos: {total}")
        print()
        
        # Mostrar resumen por año
        cursor.execute("""
            SELECT 
                CAST(SUBSTR(fecha_evento, 1, 4) AS INTEGER) as año,
                COUNT(*) as total
            FROM asistencias
            GROUP BY año
            ORDER BY año
        """)
        
        print("📅 Distribución por año:")
        print("-" * 60)
        for row in cursor.fetchall():
            año, total_año = row
            print(f"   Año {año}: {total_año} asistencias")
        
        print()
        
        # Mostrar resumen por capacitación
        cursor.execute("""
            SELECT nombre_evento, COUNT(*) as total
            FROM asistencias
            GROUP BY nombre_evento
            ORDER BY total DESC
        """)
        
        print("🎓 Distribución por capacitación:")
        print("-" * 60)
        for row in cursor.fetchall():
            evento, total_evento = row
            print(f"   {evento}: {total_evento} asistencias")
        
        print()
        print("-" * 60)
        print("🎉 ¡Datos insertados exitosamente!")
        print("✅ Ahora puedes acceder a /estadisticas en tu aplicación")
        
        conn.close()
        
    except sqlite3.Error as e:
        print(f"❌ Error de base de datos: {e}")
    except Exception as e:
        print(f"❌ Error inesperado: {e}")

if __name__ == "__main__":
    print()
    print("=" * 60)
    print("  INSERCIÓN DE DATOS DE EJEMPLO - SISTEMA DEREA")
    print("=" * 60)
    print()
    print("📚 Capacitaciones incluidas:")
    print("   1. Bases de datos")
    print("   2. Escritura Académica")
    print("   3. Estilo APA")
    print("   4. Gestor Bibliográfico")
    print("   5. Inducciones")
    print("   6. Visibilidad científica")
    print("   7. Visita de grupos")
    print()
    
    # Verificar que existe la base de datos
    import os
    if not os.path.exists('biblioteca.db'):
        print("❌ Error: No se encontró el archivo 'biblioteca.db'")
        print("   Asegúrate de estar en el directorio correcto")
        print("   y que la base de datos existe.")
        input("\nPresiona Enter para salir...")
    else:
        insertar_datos_ejemplo()
        print()
        input("Presiona Enter para salir...")